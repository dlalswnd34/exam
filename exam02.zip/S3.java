package exam02;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*3번 문제
 * 첫줄에 숫자의 총개수 N이 입력됩니다.
 * 2줄에 N개의 숫자가 랜덤하게 입력됩니다.
 * 오름차순 정렬해서 화면에 표시되는 코드를 작성하세요
 * 
 * 입력 : 5
 * (5랜덤숫자)
 * 출력 : 1 2 3 4 5
 * 
 */
public class S3 {
	public static void main(String[] args) {
		Scanner a = new Scanner(System.in);
		Random r = new Random();
		
		int b = a.nextInt();
		int[] c = new int[b];
		
		for (int i = 0; i < b; i++) {
			c[i] = r.nextInt(b+1);
		}
		for (int x : c) {
			System.out.print(x + " ");
		}
		System.out.println();
		Arrays.sort(c);
        for (int x : c) {
            System.out.print(x + " ");
        }
	}
}
