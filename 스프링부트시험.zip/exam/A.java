package com.simplecoding.simpledms.exam;

public class A {
//    1번 문제: 스프링의 DI, IOC, AOP에 대해 설명하시오
//    IOC는 객체 생성과 흐름 제어를 개발자가 아닌 스프링이 담당하는 개념
//    DI는 필요한 객체를 외부에서 주입받는 방법
//    AOP는 공통 관심사를 분리하여 코드 중복을 줄이고 유지보수를 용이하게 만드는 기술
}
