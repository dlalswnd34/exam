package com.simplecoding.simpledms.qna.service;

import com.simplecoding.simpledms.common.MapStruct;
import com.simplecoding.simpledms.qna.dto.QnaDto;
import com.simplecoding.simpledms.qna.entity.Qna;
import com.simplecoding.simpledms.qna.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class QnaService {
    private final QnaRepository qnaRepository;
    private final MapStruct mapStruct;

    public Page<QnaDto> selectQnaList(String searchKeyword,
                                      Pageable pageable) {
        Page<Qna> page=qnaRepository.selectQnaList(searchKeyword, pageable);
//       mapStruct 파일의 56번째줄에 정의
        return page.map(data->mapStruct.toDto(data));
    }
}
