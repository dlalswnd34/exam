package egovframework.example.exam4;

public class A {
//	1. 스프링 MVC 디자인 패턴에 대해서 설명해주세요 
	
//	스프링 MVC는 Model-View-Controller 패턴을 기반으로 하는 웹 애플리케이션
//	아키텍처로, 역할 분리를 통해 유지보수성과 확장성을 높이는 구조.
}
