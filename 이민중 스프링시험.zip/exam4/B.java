package egovframework.example.exam4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import egovframework.example.dept.service.DeptService;
import lombok.extern.log4j.Log4j2;

public class B {
	/*
	 * @Log4j2
	 * @Controller 
	 * public class DeptController { 
	 * 		// 서비스 가져오기 
	 * 		@Autowired 
	 * 		private DeptService deptService; 
	 * ... 
	 * }
	 */
	
}
