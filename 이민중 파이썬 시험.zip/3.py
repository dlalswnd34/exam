# https://www.saucedemo.com/ 접속 및 로그인후 나오는 첫페이지에서
# 상품설명을 모두 크롤링해서 화면에 표시하는 코딩을 하세요

import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=Options())

driver.get("https://www.saucedemo.com/")
driver.find_element(By.CSS_SELECTOR, "#user-name").send_keys("standard_user")
driver.find_element(By.CSS_SELECTOR, "#password").send_keys("secret_sauce")
driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()
time.sleep(1)

descs = driver.find_elements(By.CSS_SELECTOR, ".inventory_item_desc")

for i, d in enumerate(descs, start=1):
    print(f"{i}. {d.text}")

driver.quit()