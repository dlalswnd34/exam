-- dept 전체조회 querydsl 작성

POST /dept/_search
{
  "query": {
    "match_all": {}
  }
}