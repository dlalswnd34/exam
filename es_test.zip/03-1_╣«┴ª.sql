-- 부서별합계를 구하고 구한 부서별 급여합계를 모두더한 총합도 구하기
-- 파이프라인 형제집계를 사용할 것

POST /employees/_search
{
  "size": 0,
  "aggs": {
    "group_by_dno": {  
      "terms": { "field": "dno" }, 
      "aggs": {
        "sum_salary": {
          "sum": { "field": "salary" }
        }
      }
    },
    "total_salary_sum": { 
      "sum_bucket": {
        "buckets_path": "group_by_dno>sum_salary"
      }
    }
  }
}